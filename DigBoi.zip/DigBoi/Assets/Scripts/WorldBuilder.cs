﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class WorldBuilder : MonoBehaviour {

	public int max;
	public int min;
	public GameObject tile;
	public GameObject[,] grid = new GameObject[20,10];
	public Transform tileHolder;

	// Use this for initialization
	void Start () {
		drawMap ();

	}
	
	// Update is called once per frame
	void Update () {
		
	}

	void drawMap(){
		Vector3 start = Camera.main.ViewportToWorldPoint(new Vector3(0f, 0f, 0f));

		for (int i = 0; i < grid.GetLength(0); i++)
		{
			for (int j = 0; j < grid.GetLength(1); j++)
			{
				grid[i, j] = Instantiate(tile, start + new Vector3(i, j, 0f), Quaternion.identity,tileHolder);
			}
		}
	}
}
