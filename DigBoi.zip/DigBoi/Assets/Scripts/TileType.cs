﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TileType : TileData {

	public Sprite grass;
	public Sprite dirt;
	public Sprite water;
	public Sprite sand;

	// Use this for initialization
	void Start () {
		//base.SetSprite (TileID);
	}
	
	// Update is called once per frame
	void Update () {
		
	}
		
}
