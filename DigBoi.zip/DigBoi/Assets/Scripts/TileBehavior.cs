﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TileBehavior : MonoBehaviour {

	public PublicVariables pv;
	public GameObject GM;
	private TileID tid;
	private 

	// Use this for initialization
	void Start () {
		tid = GetComponent<TileID> ();
		GM = GameObject.Find ("GM");
		pv = GM.GetComponent<PublicVariables> ();
	}
	
	// Update is called once per frame
	void Update () {

		if (GameObject.Find ("Excavator").transform.position == this.transform.position && pv.digMode) {
			this.tid.ChangeID (2);
		}

	}

	public void Dig(){
		if (pv.digMode) { //If the public variable Dig Mode is true, then dig.

			GM.GetComponent<WorkerManager> ().MoveWorker (this.transform.position);

		}
	}


}
