﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PublicVariables : MonoBehaviour {

	public bool digMode = true;


	public void setDigMode(bool t){
		digMode = t;
	}
}
