﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class WorkerManager : MonoBehaviour {

	public GameObject worker;

	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {

	}

	public void MoveWorker(Vector3 worldPos){
		//worker.GetComponent<Movement> ().enabled = true;
		worker.GetComponent<Movement> ().Move(worldPos);
	}


}
