﻿using UnityEngine;
using LitJson;
using System.Collections.Generic;
using System.IO;

public class TileData : MonoBehaviour {


	private List<TileID> database = new List<TileID>();
	private JsonData itemData;

	void Start()
	{
	}
	
	// Update is called once per frame
	void Update () {
		
	}

	public virtual void SetSprite(int id){

		switch (id) {
		case 1:
			Debug.Log ("Grass");
			break;
		case 2:
			Debug.Log ("dirt");
			break;
		}

		//this.GetComponent<SpriteRenderer> ().color = new Color32 (255, 255, 255, 255);
		Debug.Log ("Base has been reached");
	}
}
