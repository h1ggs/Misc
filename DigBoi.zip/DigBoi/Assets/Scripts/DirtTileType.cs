﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DirtTileType : MonoBehaviour {

	public Sprite dirt;
	public TileType tt;

	// Use this for initialization
	void Start () {
		this.gameObject.GetComponent<GrassTileType> ().enabled = false;
		tt = GetComponentInParent<TileType> ();
		this.GetComponent<SpriteRenderer> ().sprite = tt.dirt;
		Debug.Log ("You've just dug a hole, ya fuck");
	}
	
	// Update is called once per frame
	void Update () {
		
	}
}
