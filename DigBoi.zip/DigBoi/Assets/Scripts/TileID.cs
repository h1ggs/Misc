﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TileID : MonoBehaviour {

	public int TileType;
	private SpriteRenderer sp;

	// Use this for initialization
	void Start () {
		ChangeID (TileType);
	}
	

	public void ChangeID (int id) {

		switch (id) {
		case 1:
			this.gameObject.AddComponent<GrassTileType> ();
			Debug.Log ("Grass");
			break;

		case 2:
			Debug.Log ("Dirt");
			this.gameObject.AddComponent<DirtTileType> ();
			break;

		case 3:
			Debug.Log ("Water");
			break;

		case 4:
			Debug.Log ("Sand");
			break;

		}
	}
}
