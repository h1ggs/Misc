﻿using System;

namespace UnityEngine.ResourceManagement.Tests {
    public class ResourceManagerPackedModeTests
    {
        //TODO: implement tests that create bundles
    }
}
