Addressable Assets info placeholder
