﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

//This static script is used by the 'DemoMenu' script to keep track of the currently selected options;
public static class PlayerData {

	public static int controllerIndex = 0;
	public static bool enableShadows = true;
}
